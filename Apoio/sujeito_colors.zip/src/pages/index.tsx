
export default function Home() {
  return (
    <div>
      <h1>Sujeito Programador</h1>
    </div>
  )
}
